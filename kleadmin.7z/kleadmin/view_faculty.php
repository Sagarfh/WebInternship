<?php include "header.php"; ?>
<?php include "sidemenu.php"; ?>
<!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

<div class="container-fluid">
	<!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">View Faculty record</h1>
            
          </div>
          <div class="row">
          	<div class="col-sm-12">
          	<div class="card">
          		<div class="card-body">
          			<table class="table table-bordered" id="view_student" width="100%" cellspacing="0">
          				<thead>
          					<tr>
          						<th>ID</th>
                      <th>Profile Pic</th>
          						<th>Faculty Name</th>
          						<th>Email</th>
          						<th>Branch</th>
          						<th>Gender</th>
          						<th>Reg Date</th>
          					</tr>
          				</thead>
          				<tbody>
          					<?php
          					$selectQuery="SELECT * FROM faculty ORDER BY id DESC";
          					$stmt=$con->query($selectQuery);
          					while($row=$stmt->fetch(PDO::FETCH_ASSOC)){

          					
          					?>
          					<tr>
          						<td><?=$row['id']?></td>
                      <td>
                        <img src="<?=(!empty($row['f_profile']))?$row['f_profile']:'';?>" class="img-fluid img-responsive">
                      </td>


          						<td><?=$row['f_name']?></td>
          						<td><?=$row['f_email']?></td>
          						<td><?=$row['f_branch']?></td>
          					
          						<td><?=$row['f_gender']?></td>
          						<td><?=$row['reg_date']?></td>
          					</tr>
          					<?php
          				}
          				?>
          				</tbody>
          			</table>
          		</div>
          	</div>
          </div>
      </div>

<?php include "footer.php"; ?>

 <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <script type="text/javascript">
  	$(document).ready(function(){
  		$('#view_student').dataTable();
  	});
  </script>

