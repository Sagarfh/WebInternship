<!DOCTYPE html>
<html>
<head>
	<title>Calculator</title>
	<meta charset="utf-8">
</head>
<body>
<center>
	<h1><u>Calculator</u></h1>
	<form>
		<h2>Enter the First Number <input type="number" name="num1" placeholder="Num1"></h2></br>
		<h2>Enter the Second Number<input type="number" name="num2" placeholder="Num2"></h2></br>
		<select name="operators"> 
			<option>Empty</option>
			<option>Addition</option>
			<option>Subtract</option>
			<option>Multiplication</option>
			<option>Division</option>
		</select>
	<br>
	<button type="submit" name="submit" value="submit">Calculate</button>
	</form>
	<p style="color:blue;font-size: 30px;">
     The Answer is:
     <?php
     if(isset($_GET['submit']))
     {
         $result1 = $_GET['num1'];
         $result2 = $_GET['num2'];
         $operators = $_GET['operators'];
         switch ($operators) {
         	case 'Empty':
         		echo "Please enter the number";
         		break;
         	case 'Addition':
         		echo $result1 + $result2;
         		break;
         	case 'Subtract':
         		echo $result1 - $result2;
         		break;
         	case 'Multiplication':
         		echo $result1 * $result2;
         		break;
         	case 'Division':
         		echo $result1 / $result2;
         		break;
         }
     }
     ?>
	</center>
</body>
</html>