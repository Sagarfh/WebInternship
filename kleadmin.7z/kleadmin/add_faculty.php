<?php include "header.php"; ?>
<?php include "sidemenu.php"; ?>
<div class="container-fluid">
  <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add Faculty Record</h1>            
          </div>
          <div class="row">
            <div class="col-sm-12">
              <div class="card">
                <div class="card-body">
                  <form method="POST" id="faculty" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="f_name">Faculty Name</label>
                          <input type="text" name="f_name" placeholder="Enter Faculty Name" class="form-control">
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="f_name">Faculty Email</label>
                          <input type="email" name="f_email" placeholder="Enter Faculty Email" class="form-control">
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="f_branch">Faculty Branch</label>
                          <select class="form-control" name="f_branch">
                            <option value="" selected="selected" disabled="disabled">--Select Branch</option>
                            <option value="cs">Computer Science</option>
                            <option value="is">Information Science</option>
                          </select>
                        </div>
                      </div>

                      

                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="f_gender">Faculty Gender</label>
                          <select class="form-control" name="f_gender">
                            <option value="" selected="selected" disabled="disabled">--Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="others">Others</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="f_profile">Profile Pic</label>
                          <input type="file" name="f_profile" class="form-control" id="profile"/>
                        </div>
                        <img src="" class="img-fluid" id="preview" style="display:none;width:200px;object-fit:scale-down"/>
                    </div>
                    <div class="col-sm-12">
                      <input type="hidden" name="faculty" value="faculty">
                      <input type="submit" name="faculty" value="Add Faculty" class="btn btn-primary">
                      <input type="reset" name="reset" value="Reset" class="btn btn-danger">
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
<?php include "footer.php"; ?>
<script type="text/javascript">
  function readURL(input){
    if(input.files && input.files[0]){
      var reader=new FileReader();
      reader.onload=function(e){
        $('#preview').attr('src',e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }


  $(document).ready(function(){

    $('#profile').change(function(){
      $('#preview').show();
      readURL(this);

    });


    $('#faculty').submit(function(e){
      e.preventDefault();
      //$data=$(this).serialize();
      $data=new FormData(this);
      swal({
        title:"Loading",
        text:"please wait....",        
        button:false
      });
      $.ajax({
        url:"php_data/process.php",
        data:$data,
        type:"POST",
        //added newly after image 
        cache:false,
        contentType:false,
        processData:false,

        success:function(result){
          result=$.parseJSON(result);
          if(result.status==='success'){
            swal({
              title:"Success",
              text:result.message,
              icon:"success"
            }).then((value)=>{
              if(value){
                location.href="view_faculty.php";
              }
            });
          }else{
            swal({
              title:"Warning",
              text:result.message,
              icon:"warning"
            });
          }
        }
      });      
    });

  })
</script>