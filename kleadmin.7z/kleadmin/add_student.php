<?php include "header.php"; ?>
<?php include "sidemenu.php"; ?>
<div class="container-fluid">
  <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add Student Record</h1>            
          </div>
          <div class="row">
            <div class="col-sm-12">
              <div class="card">
                <div class="card-body">
                  <form method="POST" id="student" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="s_name">Student Name</label>
                          <input type="text" name="s_name" placeholder="Enter Student Name" class="form-control">
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="s_name">Student Email</label>
                          <input type="email" name="s_email" placeholder="Enter Student Email" class="form-control">
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="s_branch">Student Branch</label>
                          <select class="form-control" name="s_branch">
                            <option value="" selected="selected" disabled="disabled">--Select Branch</option>
                            <option value="cs">Computer Science</option>
                            <option value="is">Information Science</option>
                          </select>
                        </div>
                      </div>

                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="s_sem">Student Semester</label>
                          <select class="form-control" name="s_sem">
                            <option value="" selected="selected" disabled="disabled">--Select Semester</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                          </select>
                        </div>
                      </div>

                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="s_gender">Student Gender</label>
                          <select class="form-control" name="s_gender">
                            <option value="" selected="selected" disabled="disabled">--Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="others">Others</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="s_profile">Profile Pic</label>
                          <input type="file" name="s_profile" class="form-control" id="profile"/>
                        </div>
                        <img src="" class="img-fluid" id="preview" style="display:none;width:200px;object-fit:scale-down"/>
                    </div>
                    <div class="col-sm-12">
                      <input type="hidden" name="student" value="student">
                      <input type="submit" name="student" value="Add Student" class="btn btn-primary">
                      <input type="reset" name="reset" value="Reset" class="btn btn-danger">
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
<?php include "footer.php"; ?>
<script type="text/javascript">
  function readURL(input){
    if(input.files && input.files[0]){
      var reader=new FileReader();
      reader.onload=function(e){
        $('#preview').attr('src',e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }


  $(document).ready(function(){

    $('#profile').change(function(){
      $('#preview').show();
      readURL(this);

    });


    $('#student').submit(function(e){
      e.preventDefault();
      //$data=$(this).serialize();
      $data=new FormData(this);
      swal({
        title:"Loading",
        text:"please wait....",        
        button:false
      });
      $.ajax({
        url:"php_data/process.php",
        data:$data,
        type:"POST",
        //added newly after image 
        cache:false,
        contentType:false,
        processData:false,

        success:function(result){
          result=$.parseJSON(result);
          if(result.status==='success'){
            swal({
              title:"Success",
              text:result.message,
              icon:"success"
            }).then((value)=>{
              if(value){
                location.href="view_student.php";
              }
            });
          }else{
            swal({
              title:"Warning",
              text:result.message,
              icon:"warning"
            });
          }
        }
      });      
    });

  })
</script>