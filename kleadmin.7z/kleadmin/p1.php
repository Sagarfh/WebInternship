<!DOCTYPE html>
<html>
<head>
	<title>PHP Program</title>
</head>
<body>
	<?php
	$message="Hello world";
	for($i=0;$i<9;$i++)
	{
		echo $i." :".$message."<br/>";
	} 


	?>


</body>
</html>