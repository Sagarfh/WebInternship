<?php include "header.php"; ?>
<?php include "sidemenu.php"; ?>
<?php
$selectQuery="SELECT COUNT(usn) as tot_student,count(DISTINCT s_branch) as tot_branch,sum(CASE when s_gender='male' then 1 else 0 end) as tot_male,sum(case when s_gender='female' then 1 else 0 end) as tot_female from student";
$stmt=$con->query($selectQuery);
$row=$stmt->fetch(PDO::FETCH_ASSOC);
$tot_student=$row['tot_student'];
$tot_branch=$row['tot_branch'];
$tot_male=$row['tot_male'];
$tot_female=$row['tot_female'];
?>

<div class="container-fluid">
  <h1 class="h3 mb-0 text-gray-800"> <u>Dashboard </u></h1> </br>
</div>

  <div class="container-fluid">

	<!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            
             
            <h1 class="h3 mb-0 text-gray-800">Students</h1> </br>
            <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
          </div>
          <!-- Content Row -->
          <div class="row">
          	<div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Students</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$tot_student?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-users fa-2x" style="color: #00FA9A"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Branches</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$tot_branch?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-code-branch fa-2x" style="color: #E83030"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Male Students</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$tot_male?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas  fa-male fa-2x" style="color: #0276FD"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Female Students</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$tot_female?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-female fa-2x" style="color: #FF69B4"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


<?php
$selectQuery="SELECT COUNT(id) as tot_faculty,count(DISTINCT f_branch) as tot_branch,sum(CASE when f_gender='male' then 1 else 0 end) as tot_male,sum(case when f_gender='female' then 1 else 0 end) as tot_female from faculty";
$stmt=$con->query($selectQuery);
$row=$stmt->fetch(PDO::FETCH_ASSOC);
$tot_faculty=$row['tot_faculty'];
$tot_branch=$row['tot_branch'];
$tot_male=$row['tot_male'];
$tot_female=$row['tot_female'];
?>

<div class="container-fluid">
  <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Faculty</h1>
            <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
          </div>
          <!-- Content Row -->
          <div class="row">
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Faculties</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$tot_faculty?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-users fa-2x" style="color: #00FA9A"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Branches</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$tot_branch?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-code-branch fa-2x" style="color: #E83030"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Male Faculties</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$tot_male?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas  fa-male fa-2x" style="color: #0276FD"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Female Faculties</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$tot_female?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-female fa-2x" style="color: #FF69B4"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


<?php include "footer.php"; ?>