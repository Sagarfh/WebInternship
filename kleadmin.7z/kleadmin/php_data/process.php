<?php include "../config/db-config.php";

if(isset($_POST['login'])){

	$selectQuery="SELECT * FROM admin WHERE email =? and password =?";
	$stmt=$con->prepare($selectQuery);
	$stmt->bindParam(1,$_POST['email']);
	$stmt->bindParam(2,$_POST['password']);
	$stmt->execute();
	$count=$stmt->rowCount();
	if($count>0 && $count<2){
		echo json_encode(array("status"=>"success","message"=>"login successful. click ok to login"));
	}else{
		echo json_encode(array("status"=>"failed","message"=>"invalid credentials"));
	}
}
if(isset($_POST['forgot'])){
	$selectQuery="SELECT * FROM admin 
	WHERE email =?";
	$stmt=$con->prepare($selectQuery);
	$stmt->bindParam(1,$_POST['email']);
	$stmt->execute();
	$count=$stmt->rowCount();
	if($count===1){
		echo json_encode(array("status"=>"success","message"=>"Redirecting to Reset Password Page. Click ok to proceed","email"=>$_POST['email']));
	}else{
		echo json_encode(array("status"=>"failed","message"=>"Forgotton EMail id. Please Contact Developer"));
	}
}
if(isset($_POST['reset'])){
	if($_POST['password']!== $_POST['confirm_password']){
		echo json_encode(array("status"=>"failed","message"=>"New Password and confirm password didnt match"));
		exit();
	}
	else{
		$updateQuery="UPDATE admin SET password=? WHERE email=?";
		$stmt=$con->prepare($updateQuery);
		$stmt->bindParam(1,$_POST['password']);
		$stmt->bindParam(2,$_POST['reset']);
		if($stmt->execute()){
			echo json_encode(array("status"=>"success","message"=>"reset password successful. click ok to proceed"));
			exit();
		}
		else{
			echo json_encode(array("status"=>"failed","message"=>"something went wrong. please try after some time"));
			exit();
		}
	}
}
if(isset($_POST['student'])){
	$selectQuery="SELECT * FROM student WHERE s_email=? and s_branch=? and s_sem=?";
		$stmt=$con->prepare($selectQuery);
		$stmt->bindParam(1,$_POST['s_email']);
		$stmt->bindParam(2,$_POST['s_branch']);
		$stmt->bindParam(3,$_POST['s_sem']);
		$stmt->execute();
		$count=$stmt->rowCount();
		if($count>0){
			echo json_encode(array("status"=>"failed","message"=>"Student Already Enrolled"));
			exit();
			}else{
				$valid_extensions=array("jpeg","jpg","png","gif","bmp");
				$path="";
				if(!empty($_FILES['s_profile'])){
					$file_name=$_FILES['s_profile']['name'];
					$file_tmp=$_FILES['s_profile']['tmp_name'];
					$ext=strtolower(pathinfo($file_name,PATHINFO_EXTENSION));
					$final_img=rand(10000,100000).$file_name;
					if(in_array($ext,$valid_extensions)){
						$actual_path="../img/".$final_img;
						if(move_uploaded_file($file_tmp,$actual_path )){
							$path="img/".$final_img;
						}
					}else{
						echo json_encode(array("status"=>"invalid","message"=>"Invalid Image File Format"));
						exit();
					}
				}else{
					$path="";
				}
	
		//$insertQuery="INSERT INTO student(s_name,s_email,s_branch,s_sem,s_gender) VALUES('".$_POST["s_name"]."','".$_POST["s_email"]."','".$_POST["s_branch"]."','".$_POST["s_sem"]."','".$_POST["s_gender"]."')";
		$insertQuery="INSERT INTO student SET s_name=?,s_email=?,s_branch=?,s_sem=?,s_gender=?,s_profile=?";
		$stmt=$con->prepare($insertQuery);
		$stmt->bindParam(1,$_POST['s_name']);
		$stmt->bindParam(2,$_POST['s_email']);
		$stmt->bindParam(3,$_POST['s_branch']);
		$stmt->bindParam(4,$_POST['s_sem']);
		$stmt->bindParam(5,$_POST['s_gender']);
		$stmt->bindParam(6,$path);

		if($stmt->execute()){
			echo json_encode(array("status"=>"success","message"=>"Student Added"));
			exit();
		}else{
			echo json_encode(array("status"=>"failed","message"=>"something went wrong.....Please try after some time"));
		}
	}
}


if(isset($_POST['faculty'])){
	$selectQuery="SELECT * FROM faculty WHERE f_email=? and f_branch=?";
		$stmt=$con->prepare($selectQuery);
		$stmt->bindParam(1,$_POST['f_email']);
		$stmt->bindParam(2,$_POST['f_branch']);
		$stmt->execute();
		$count=$stmt->rowCount();
		if($count>0){
			echo json_encode(array("status"=>"failed","message"=>"Faculty Already Enrolled"));
			exit();
			}else{
				$valid_extensions=array("jpeg","jpg","png","gif","bmp");
				$path="";
				if(!empty($_FILES['f_profile'])){
					$file_name=$_FILES['f_profile']['name'];
					$file_tmp=$_FILES['f_profile']['tmp_name'];
					$ext=strtolower(pathinfo($file_name,PATHINFO_EXTENSION));
					$final_img=rand(10000,100000).$file_name;
					if(in_array($ext,$valid_extensions)){
						$actual_path="../img/".$final_img;
						if(move_uploaded_file($file_tmp,$actual_path )){
							$path="img/".$final_img;
						}
					}else{
						echo json_encode(array("status"=>"invalid","message"=>"Invalid Image File Format"));
						exit();
					}
				}else{
					$path="";
				}
	
		//$insertQuery="INSERT INTO student(s_name,s_email,s_branch,s_sem,s_gender) VALUES('".$_POST["s_name"]."','".$_POST["s_email"]."','".$_POST["s_branch"]."','".$_POST["s_sem"]."','".$_POST["s_gender"]."')";
		$insertQuery="INSERT INTO faculty SET f_name=?,f_email=?,f_branch=?,f_gender=?,f_profile=?";
		$stmt=$con->prepare($insertQuery);
		$stmt->bindParam(1,$_POST['f_name']);
		$stmt->bindParam(2,$_POST['f_email']);
		$stmt->bindParam(3,$_POST['f_branch']);
		$stmt->bindParam(4,$_POST['f_gender']);
		$stmt->bindParam(5,$path);

		if($stmt->execute()){
			echo json_encode(array("status"=>"success","message"=>"Faculty Added"));
			exit();
		}else{
			echo json_encode(array("status"=>"failed","message"=>"something went wrong.....Please try after some time"));
		}
	}
}

	

?>

