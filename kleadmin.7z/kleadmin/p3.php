<!DOCTYPE html>
<html>
<head>
	<title>Factorial Number</title>
</head>
<body>
	<center>
		<form method="POST">
			<h1><u>Factorial</u></h1>
			<h2>Enter the number <font color="red">*</font></h2><input type="Number" name="no" required></br>
			<input type="submit" name="submit"></br>
			<p style="color: blue;font-size: 30px;">
				<?php
					if (isset($_POST['submit']))
					 {
						$no = $_POST['no'];
						function factorial($fact)
						{
							if ($fact == 0) {
								return 1;
							}
							return $fact*factorial($fact-1);
						}
						$msg=factorial($no);
						echo "The factorial of $no is ".($msg)."</br>";
					}
				?>
			</p>
			
		</form>
	</center>

</body>
</html>