-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2020 at 08:27 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kleadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `slno` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`slno`, `email`, `password`, `profile_pic`, `name`, `reg_date`) VALUES
(1, 'admin@gmail.com', '1234', '', 'admin', '2019-07-15 07:55:05');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `f_email` varchar(255) NOT NULL,
  `f_gender` varchar(255) NOT NULL,
  `f_branch` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `f_profile` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `f_name`, `f_email`, `f_gender`, `f_branch`, `reg_date`, `f_profile`) VALUES
(1, 'kiran', 'kiran@gmail.com', 'male', 'cs', '2019-07-19 10:01:26', ''),
(2, 'vishwanath', 'vishwanath@gmail.com', 'male', 'cs', '2019-07-19 10:25:58', 'img/39148logo.png'),
(3, 'karuna', 'karuna@gmail.com', 'female', 'cs', '2019-07-19 10:37:49', 'img/72416logo.png'),
(4, 'mahantesh', 'mahantesh@gmail.com', 'male', 'is', '2019-08-31 10:28:24', 'img/10674icon.png');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `usn` int(11) NOT NULL,
  `s_name` varchar(255) NOT NULL,
  `s_email` varchar(255) NOT NULL,
  `s_gender` varchar(255) NOT NULL,
  `s_branch` varchar(255) NOT NULL,
  `s_sem` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `s_profile` varchar(255) NOT NULL,
  `s_clg` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`usn`, `s_name`, `s_email`, `s_gender`, `s_branch`, `s_sem`, `reg_date`, `s_profile`, `s_clg`) VALUES
(1, 'rajesh', 'rajesh@gmail.com', 'male', 'cs', '5', '2019-07-17 07:31:07', '', ''),
(2, 'mukesh', 'mukesh@gmail.com', 'male', 'cs', '5', '2019-07-17 07:31:07', '', ''),
(3, 'sagar', 'sagar@gmail.com', 'male', 'cs', '5', '2019-07-17 07:32:03', '', ''),
(4, 'anil', 'anil@gmail.com', 'male', 'cs', '5', '2019-07-17 07:32:03', '', ''),
(5, 'tara', 'tara@gmail.com', 'female', 'is', '2', '2019-07-17 07:33:56', '', ''),
(6, 'anu', 'anu@gmail.com', 'female', 'is', '5', '2019-07-17 07:33:56', '', ''),
(7, 'pawan', 'pawan@gmail.com', 'male', 'cs', '7', '2019-07-19 05:49:56', '', ''),
(10, 'rajesh', 'rajesh@gmail.com', 'male', 'is', '5', '2019-07-19 06:38:44', '', ''),
(11, 'siddu', 'siddu@gmail.com', 'male', 'is', '5', '2019-07-19 08:50:55', 'img/51233icon.png', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`slno`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`usn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `slno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `usn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
