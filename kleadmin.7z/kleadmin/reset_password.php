<?php include "header.php"; ?>
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">
        <center><img src="img/logo.png"></center>

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
              <div class="col-lg-6">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                  </div>
                  <?php
                  if(isset($_GET['email'])){
                    ?>
                  
                  <form class="user" method="POST" id="reset">
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter New Password" name="password">
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="Confirm Password" name="confirm_password">
                    
                    </div>

                    <input type="hidden" name="reset" value="<?=$_GET['email']?>">
                    <button type="submit" class="btn btn-primary btn-user btn-block">Login</button> 
                      
                    
                    <hr>
                    
                  </form>
                    <?php      
                      }else{
                  ?>
                    <h3>User Not Allowed to acces  this page.  <a href="reset_password.php">Click here to go back</a>
                    </h3>
                  <?php      
                      }
                  ?>
                  <hr>
                  <div class="text-center">
                    <a class="small" href="login.php">Login</a>
                  </div>
                                  </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>
  <?php include "footer.php";?>
  <script type="text/javascript">
    $(document).ready(function(){
    //{
      //alert('loading Login page')
    //})
    //{
     $('#reset').submit(function(e){
        e.preventDefault();
        //alert('Login form submitted')
        $data=$(this).serialize();
        console.log($data);
        //swal('Login form submitted');
        swal({
          title:"loading",
          text:"please wait....",
          button:false
        });
        $.ajax({
          url:"php_data/process.php",
          data:$data,
          type:"POST",
          success:function(result){
            result=$.parseJSON(result);
            if(result.status==='success'){
              swal({
                title:"Success",
                text:result.message,
                icon:"success"
              }).then((value)=>{
                if(value){
                  location.href="dashboard.php";
                }
              });
            }else{
              swal({
                title:"warning",
                text:result.message,
                icon:"warning",
              });
            }
          }
        });
          
      });
    })
  </script>