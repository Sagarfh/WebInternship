<!DOCTYPE html>
<html>
<head>
	<title>PHP PROGRAM</title>
</head>
<body>
	<form method="POST" action="">
		<input type="number" name="num">
		<input type="submit" name="submit" value="submit">
		<?php
		if(isset($_POST['submit'])){
			$num=$_POST['num'];
			echo "<br/>";
			for($i=1;$i<=10;$i++){
				echo "$num * $i = ".($num*$i)." <br/>";
			}
		}

	?>	
	</form>

</body>
</html>